﻿using SalonBookingApi.Models;
using System;
using System.ComponentModel.DataAnnotations;

namespace SalonBookingApi.Models
{
    public class Appointment
    {
        [Key]
        public int Appointment_ID { get; set; }
        public string Customer_Name { get; set; }
        public DateTime Appointment_Date { get; set; }
        public string Service { get; set; }
    }
}