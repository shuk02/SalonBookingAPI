﻿using Microsoft.EntityFrameworkCore;
using SalonBookingApi.Models;

namespace SalonBookingApi.Data
{
    public class SalonBookingContext : DbContext
    {
        public SalonBookingContext(DbContextOptions<SalonBookingContext> options) : base(options) { }

        public DbSet<Customer> Customers { get; set; }
        public DbSet<Appointment> Appointments { get; set; }
    }
}