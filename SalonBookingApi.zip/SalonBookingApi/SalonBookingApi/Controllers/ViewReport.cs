﻿namespace SalonBookingApi.Controllers
{
    public class ViewReport
    {
    }
}
