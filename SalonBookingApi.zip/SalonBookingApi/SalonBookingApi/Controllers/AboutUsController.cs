﻿using Microsoft.AspNetCore.Mvc;
using SalonBookingApi.Models;
using System.Diagnostics;

namespace SalonBookingApi.Controllers
{
    public class AboutUsController : Controller // Inherit from Controller
    {
        private readonly ILogger<AboutUsController> _logger;

        public AboutUsController(ILogger<AboutUsController> logger)
        {
            _logger = logger;
        }

        // AboutUs action method
        public IActionResult AboutUs()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext?.TraceIdentifier });
        }
    }
}
